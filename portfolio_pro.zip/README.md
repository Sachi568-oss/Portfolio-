# Samora Machel - Professional Portfolio

Welcome to my professional portfolio website!

## About Me
I am a skilled **Transcriptionist** and **Copywriter** with 3 years of experience delivering accurate transcription and engaging, SEO-friendly copy.

## Services
- Audio & Video Transcription (99% accuracy)
- SEO Content Writing
- Product Descriptions & Sales Copy
- Blog & Article Writing
- Proofreading & Editing

## Contact
- **Email:** ochiengsam3.os@gmail.com

---
**© 2025 Samora Machel. All Rights Reserved.**
